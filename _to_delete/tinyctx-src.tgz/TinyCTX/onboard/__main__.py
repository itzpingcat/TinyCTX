"""
TinyCTX Onboarding Wizard
Run with: python -m onboard          (from repo root)
          python -m onboard --reset
"""

from __future__ import annotations

import argparse
import sys
from typing import Any

import questionary
from rich.markdown import Markdown
from rich.panel import Panel

from .helpers import (
    BANNER,
    CONFIG_PATH,
    GoBack,
    Mode,
    QSTYLE,
    assemble_config,
    c,
    load_beginner_providers,
    load_existing_config,
    load_providers,
    section,
    success,
    warn,
    write_config,
)
from . import providers_setup, bridges_setup, workspace_setup, gateway_setup
from .fix_permissions import elevate_user, list_users


# ── Step 0a: detect existing config ──────────────────────────────────────────

def step_detect(reset: bool) -> str:
    """Returns 'new' | 'modify' | 'reset'."""
    if not CONFIG_PATH.exists():
        return "new"

    section("Existing Configuration Detected")
    c.print(f"Found [bold]{CONFIG_PATH}[/]")

    if load_existing_config() is None:
        c.print("[bold red]✗[/] Config is invalid — run [bold]python -m onboard --reset[/] to start fresh.")
        sys.exit(1)

    if reset:
        return "reset"

    choice = questionary.select(
        "What would you like to do?",
        choices=[
            "Keep existing config (exit)",
            "Modify (update specific sections)",
            "Reset (start from scratch)",
        ],
        default="Modify (update specific sections)",
        style=QSTYLE,
    ).ask()

    if choice is None or "Keep" in choice:
        success("Nothing changed.")
        sys.exit(0)

    return "reset" if "Reset" in choice else "modify"


# ── Step 0b: beginner or pro? ─────────────────────────────────────────────────

def step_select_mode() -> Mode:
    section("Setup Mode")
    c.print("Choose how much you want to configure:\n")

    choice = questionary.select(
        "Which setup experience would you like?",
        choices=[
            "🟢  Quick Start  — I'm new to AI agents, just get me going",
            "🟡  Standard     — I know what I'm doing",
            "← Back",
        ],
        style=QSTYLE,
    ).ask()

    if choice is None:
        sys.exit(0)
    if "Back" in choice:
        raise GoBack

    if "Quick Start" in choice:
        c.print("\n[bold green]Quick Start[/] selected — we'll keep things simple!\n")
        return "quickstart"
    elif "Standard" in choice:
        c.print("\n[bold yellow]Standard[/] selected.\n")
        return "standard"
    else:
        c.print("\n[bold red]Advanced[/] selected — buckle up.\n")
        return "advanced"


# ── optional: advanced agent settings ─────────────────────────────────────────

def step_max_tool_cycles(mode: Mode) -> int:
    if mode != "advanced":
        return 25
    section("Agent Settings")
    c.print("Max tool cycles: how many tool calls the agent can make per turn before stopping.\n")
    return int(questionary.text("max_tool_cycles", default="25", style=QSTYLE).ask() or "25")


# ── final: summary ─────────────────────────────────────────────────────────────

def step_summary(mode: Mode, gateway: dict[str, Any]) -> None:
    section("Done!")
    host, port, key = gateway["host"], gateway["port"], gateway["api_key"]

    if mode == "quickstart":
        body = Markdown(f"""
**Config written to:** `{CONFIG_PATH}`

### Next steps

1. **Set your API key** if you haven't already:
   - Windows: `set YOUR_PROVIDER_API_KEY=sk-...`
   - Mac/Linux: `export YOUR_PROVIDER_API_KEY=sk-...`

2. **Start TinyCTX:**
   ```
   python -m main
   ```

3. **Connect a client** (e.g. SillyTavern) to:
   - URL: `http://{host}:{port}`
   - API Key: `{key}`

That's it! Re-run `python -m onboard` at any time to reconfigure.
""")
        c.print(Panel(body, title="[bold green]TinyCTX is ready 🎉[/]", border_style="green"))

    else:
        body = Markdown(f"""
**Config written to:** `{CONFIG_PATH}`

**Next steps:**

1. Set any missing environment variables (API keys, bot tokens).
2. Start the agent: `python -m main`
3. Gateway: `http://{host}:{port}`  |  Key: `{key}`
4. To reconfigure: re-run `python -m onboard`
""")
        title = "[bold green]TinyCTX is ready[/]"
        if mode == "advanced":
            body = Markdown(str(body.markup) + "\n5. For advanced tuning, edit `config.yaml` directly.")
        c.print(Panel(body, title=title, border_style="green"))


# ── optional: bootstrap admin user ──────────────────────────────────────────

def step_bootstrap_admin() -> None:
    """
    After a fresh install, offer to elevate one existing user to level 100.

    If no users exist yet (gateway just launched, nobody has sent a message),
    we skip this step silently — the user can run `tinyctx launch cli` without
    a --user flag and will be prompted to elevate at that point instead.
    """
    section("Admin User (optional)")

    try:
        from TinyCTX.users import UserStore
        from .helpers import INSTANCE_DIR
        store = UserStore(INSTANCE_DIR / "data")
        users = list_users(store)
    except Exception as exc:
        warn(f"Could not open users.db: {exc}")
        return

    if not users:
        c.print(
            "  No users found yet — they are created automatically when someone"
            " first sends a message.\n"
            "  Run [bold]tinyctx launch cli --user USERNAME[/] after your first"
            " message to elevate your user to admin."
        )
        return

    already_admin = [u for u in users if u.permission_level >= 100]
    if already_admin:
        success(
            "Admin already set: "
            + ", ".join(f"[bold]{u.username}[/] (level {u.permission_level})" for u in already_admin)
        )
        return

    c.print("  Elevate a user to level 100 to grant full admin access.\n")
    choices = [
        questionary.Choice(
            title=f"{u.username}  (level {u.permission_level})",
            value=u.username,
        )
        for u in users
    ] + [questionary.Choice(title="Skip for now", value=None)]

    chosen = questionary.select(
        "Which user should be the admin?",
        choices=choices,
        style=QSTYLE,
    ).ask()

    if not chosen:
        c.print(
            "  Skipped. Run [bold]tinyctx launch cli --user USERNAME[/]"
            " to elevate later."
        )
        return

    try:
        elevate_user(chosen, 100, store)
        success(f"[bold]{chosen}[/] elevated to level 100.")
    except Exception as exc:
        warn(f"Could not elevate user: {exc}")


# ── wizard runner (with GoBack support) ──────────────────────────────────────

def run_wizard(providers: dict, beginner_providers: dict, existing: dict | None, modify: bool = False) -> None:
    """
    Run all wizard steps in order.
    Any step can raise GoBack to return to the previous step.
    In modify mode, the user picks which steps to run; others keep existing values.
    """

    step_idx = 0
    mode: Mode = "standard"
    results: dict[str, Any] = {}

    # Pre-populate results from existing config so skipped steps don't blow up assemble_config
    if existing and modify:
        # Reconstruct minimal results from existing config
        primary = existing.get("models", {}).get("primary", {})
        results["model_cfg"] = {**primary, "context": existing.get("context", 16384)}
        embed = existing.get("models", {}).get("embed")
        results["embed_cfg"] = embed
        results["workspace"] = existing.get("workspace", {}).get("path", "~/.tinyctx")
        results["filesystem_read_only_paths"] = existing.get("filesystem", {}).get("read_only_paths", [])
        results["bridges"]   = existing.get("bridges", {"cli": {"enabled": True}})
        results["gateway"]   = existing.get("gateway", {})

    all_steps = ["mode", "providers", "bridges", "workspace", "gateway"]
    step_labels = {
        "providers": "Providers & Models",
        "bridges":   "Bridges",
        "workspace": "Workspace",
        "gateway":   "Gateway",
    }

    if modify:
        section("Modify Configuration")
        c.print("Choose which sections you'd like to reconfigure:\n")
        c.print("  [dim]Space to select · Enter to confirm[/]\n")
        chosen_steps = questionary.checkbox(
            "Which sections would you like to update?",
            choices=[questionary.Choice(title=label, value=key) for key, label in step_labels.items()],
            style=QSTYLE,
        ).ask()
        if not chosen_steps:
            success("Nothing changed.")
            sys.exit(0)
        steps = chosen_steps
    else:
        steps = all_steps

    while step_idx < len(steps):
        current = steps[step_idx]
        try:
            if current == "mode":
                mode = step_select_mode()

            elif current == "providers":
                results["model_cfg"] = providers_setup.run(providers, beginner_providers, mode)
                results["embed_cfg"] = providers_setup.run_embeddings(providers, mode)

            elif current == "bridges":
                results["bridges"] = bridges_setup.run(mode)

            elif current == "workspace":
                results["workspace"] = workspace_setup.run(mode)
                results["filesystem_read_only_paths"] = workspace_setup.ask_app_whitelist(mode)

            elif current == "gateway":
                # Collect config only — do NOT launch yet (config not written yet)
                results["gateway"] = gateway_setup.run(mode)

            step_idx += 1

        except GoBack:
            if step_idx > 0:
                step_idx -= 1
                c.print("\n[dim]↩  Going back…[/]\n")
            else:
                c.print("\n[dim]Already at the first step.[/]\n")

    # ── Agent settings (advanced only, no GoBack needed) ─────────────────────
    max_tool_cycles = step_max_tool_cycles(mode)

    # ── Write config ──────────────────────────────────────────────────────────
    data = assemble_config(
        results["model_cfg"],
        results.get("embed_cfg"),
        results["workspace"],
        results["gateway"],
        results["bridges"],
        max_tool_cycles,
        existing,
        results.get("filesystem_read_only_paths", []),
    )
    write_config(data)
    success(f"Config written to [bold]{CONFIG_PATH}[/]")

    # ── Launch gateway AFTER config is on disk (only if gateway was reconfigured) ──
    if not modify or "gateway" in steps:
        gateway_setup.launch(results["gateway"])

    # ── Bootstrap admin user ───────────────────────────────────────────────────
    # Only on fresh setup (not modify). Lists all known users and asks which
    # one to elevate to level 100. Skipped if users.db has no users yet
    # (first-ever launch — users appear after the first message is sent).
    if not modify:
        step_bootstrap_admin()

    step_summary(mode, results["gateway"])


# ── entry point ───────────────────────────────────────────────────────────────

def main() -> None:
    p = argparse.ArgumentParser(
        prog="python -m onboard",
        description="TinyCTX Onboarding Wizard",
    )
    p.add_argument("--reset", action="store_true", help="Wipe existing config and start fresh")
    args = p.parse_args()

    providers          = load_providers()
    beginner_providers = load_beginner_providers()
    existing           = load_existing_config()

    c.print(f"[bold cyan]{BANNER}[/]")

    detect = step_detect(args.reset)
    if detect == "reset":
        CONFIG_PATH.unlink(missing_ok=True)
        existing = None
        success("Config reset.")
    elif detect == "new":
        c.print(Panel(
            "[bold]Welcome![/] Let's get TinyCTX configured.\n\n"
            "  • Press [bold]Ctrl+C[/] at any time to cancel.\n"
            "  • You can undo your last choice by selecting [bold]← Back[/].",
            border_style="cyan",
        ))

    try:
        run_wizard(providers, beginner_providers, existing, modify=(detect == "modify"))
    except KeyboardInterrupt:
        c.print("\n\n[bold yellow]Onboarding cancelled.[/] Run [bold]python -m onboard[/] to start again.")
        sys.exit(0)


if __name__ == "__main__":
    main()
