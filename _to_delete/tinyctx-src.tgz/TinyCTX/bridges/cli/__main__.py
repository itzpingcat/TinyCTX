"""
bridges/cli/__main__.py — Interactive CLI bridge (detached / HTTP mode).

In the new architecture the CLI bridge does NOT run inside the daemon. It
attaches to a running TinyCTX daemon over HTTP/SSE on demand via
`tinyctx launch cli`.

MANUAL_LAUNCH = True tells main.py's auto-start loop to skip this bridge.

Entry points
------------
run(gateway)              No-op. Called by main.py before the MANUAL_LAUNCH
                          check fires — never actually reached.
run_detached(...)         Real entry point. Called by commands/launch.py.
                          Connects to the daemon over HTTP and runs the TUI.

What is unchanged
-----------------
  CLITheme, CLIBridge.__init__, _console, _theme, _reply_done
  handle_event, _start_reply
  _preprocess (code block label injection)
  _read_clipboard_text, _write_clipboard_text
  /copy, /paste, /think built-in slash commands
  _prompt (async stdin reader)
  _load_cli_cursor_path / _save_cli_cursor_path (cursor file helpers)

What changed
------------
  CLIBridge gains _gateway_url and _api_key (set by run_detached).
  _send() POSTs to /v1/lane/message and reads SSE instead of calling router.
  /reset calls POST /v1/lane/branch then POST /v1/lane/open.
  Module slash commands are dispatched to POST /v1/lane/command before
    falling through to built-in handlers or the message router.
  /help fetches GET /v1/commands to include module-registered commands.
  outbound_files SSE events print delivered file paths to the console.
"""
from __future__ import annotations

import asyncio
import json
import re
import logging
from dataclasses import dataclass, field
from pathlib import Path

import sys
import pyfiglet

if sys.platform == "win32":
    import ctypes
    kernel32 = ctypes.windll.kernel32
    kernel32.SetConsoleMode(kernel32.GetStdHandle(-11), 7)

from rich.console import Console
from rich.logging import RichHandler
from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text

logger = logging.getLogger(__name__)

# Sentinel: main.py skips bridges that set this to True.
MANUAL_LAUNCH = True

# --- Code block label injection ---

_FENCED_CODE = re.compile(r'^```[ \t]*(\w+)[ \t]*\n(.*?)\n```[ \t]*$', re.DOTALL | re.MULTILINE)

def _preprocess(text: str) -> str:
    def _label(m: re.Match) -> str:
        lang, body = m.group(1), m.group(2)
        return f'*{lang}*\n```{lang}\n{body}\n```'
    return _FENCED_CODE.sub(_label, text)

# --- Theme & UI ---

@dataclass
class CLITheme:
    colors: dict[str, str] = field(default_factory=dict)
    text: dict[str, str] = field(default_factory=dict)

    def c(self, key: str) -> str:
        defaults = {
            "banner": "bright_cyan", "tagline": "bright_black", "border": "bright_black",
            "user_label": "green", "agent_label": "cyan", "thinking": "yellow",
            "tool_call": "bright_black", "tool_ok": "green", "tool_error": "red",
            "reset": "yellow", "error": "red",
        }
        return self.colors.get(key) or defaults.get(key, "")

    def t(self, key: str) -> str:
        defaults = {
            "name": "TinyCTX", "tagline": "Agent Framework",
            "user_label": "You", "agent_label": "Agent", "bye_message": "Bye.",
        }
        return self.text.get(key) or defaults.get(key, "")


# --- Fake event objects for handle_event ---
# The renderer reads only: .text, .tool_name, .args, .call_id,
#                          .output, .is_error, .message
# We don't need real contract dataclasses for the HTTP path.

class _FakeThinkingChunk:
    def __init__(self, text): self.text = text
class _FakeTextChunk:
    def __init__(self, text): self.text = text
class _FakeTextFinal:
    # suppressed mirrors AgentTextFinal.suppressed (NO_REPLY sentinel). The
    # gateway has always sent it in the SSE payload and handle_event has always
    # read it, but it was never plumbed through here — so NO_REPLY never
    # registered on the CLI path.
    def __init__(self, text, suppressed=False):
        self.text = text; self.suppressed = suppressed
class _FakeToolCall:
    def __init__(self, tool_name, call_id, args):
        self.tool_name = tool_name; self.call_id = call_id; self.args = args
class _FakeToolResult:
    def __init__(self, tool_name, call_id, output, is_error):
        self.tool_name = tool_name; self.call_id = call_id
        self.output = output; self.is_error = is_error
class _FakeError:
    def __init__(self, message): self.message = message

# Import the real contract types only for isinstance checks in handle_event.
from TinyCTX.contracts import (
    AgentThinkingChunk, AgentTextChunk, AgentTextFinal,
    AgentToolCall, AgentToolResult, AgentError,
)

# --- The Bridge ---

class CLIBridge:
    def __init__(self, gateway, options: dict | None = None) -> None:
        # gateway is None in detached mode; kept for signature compat.
        self._gateway     = gateway
        self._theme       = CLITheme(
            colors=options.get("customcolors") or {} if options else {},
            text=options.get("customtext") or {} if options else {}
        )
        # force_terminal=True keeps ANSI colour on Windows when stdout isn't
        # detected as a tty. Output is append-only (see _emit_text), so no
        # cursor-repositioning behaviour is relied on here.
        self._console     = Console(highlight=False, force_terminal=True)
        self._reply_done  = asyncio.Event()

        self._current_content = ""    # full streamed reply, kept for _last_reply
        self._stream_buf      = ""    # streamed text not yet printed (partial block)
        self._think_buf       = ""    # partial thinking line
        self._thinking_shown  = False
        self._printed_block   = False # any block printed yet this reply
        self._cursor: str | None = None   # node_id cursor, managed locally
        self._label_printed   = False
        self._last_reply: str = ""
        self._show_thinking: bool = bool(
            options.get("show_thinking", False) if options else False
        )
        # default_to_resume: reattach to the previous session on launch instead
        # of starting a fresh branch. Off by default — see run_detached().
        self._default_to_resume: bool = bool(
            options.get("default_to_resume", False) if options else False
        )
        self._resume_cursor: str | None = None  # previous session, for /resume

        # Set by run_detached before run() is called.
        self._gateway_url: str = ""
        self._api_key: str     = ""
        self._cli_username: str | None = None  # TinyCTX username for this session
        self._cli_agent_name: str | None = None  # agent_name from bridge config
        self._instance_dir: Path | None = None  # set by run_detached; used for cursor persistence

    # --- HTTP helpers ---

    def _http_headers(self) -> dict:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type":  "application/json",
        }

    async def _api_post(self, path: str, payload: dict) -> dict:
        """POST JSON to the gateway, return parsed response dict."""
        import aiohttp
        url = f"{self._gateway_url}{path}"
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload,
                                    headers=self._http_headers()) as resp:
                resp.raise_for_status()
                return await resp.json()

    async def _api_get(self, path: str) -> dict:
        """GET from the gateway, return parsed response dict."""
        import aiohttp
        url = f"{self._gateway_url}{path}"
        async with aiohttp.ClientSession() as session:
            async with session.get(url, headers=self._http_headers()) as resp:
                resp.raise_for_status()
                return await resp.json()

    # --- Slash command dispatch via gateway ---

    async def _dispatch_gateway_command(self, text: str) -> bool:
        """
        POST /v1/lane/command for module-registered slash commands.

        Returns True if the gateway handled the command (bridge should not
        fall through to built-ins or push as a message).

        The gateway returns {"handled": true/false, "output": "..."}.
        When handled, output is printed to the console.
        When not handled, we return False so built-in handling can proceed.
        """
        c = self._theme.c
        try:
            data = await self._api_post(
                "/v1/lane/command",
                {"node_id": self._cursor, "text": text},
            )
        except Exception as exc:
            # Network / server error — fall through to built-ins.
            logger.debug("[cli] /v1/lane/command request failed: %s", exc)
            return False

        if not data.get("handled", False):
            return False

        # command_introspection may have written real nodes for this command
        # onto the branch (see utils/commands.py) and returned the new tail —
        # advance our cursor past them, same as we do for /v1/lane/message,
        # so the next thing we send attaches after them instead of orphaning
        # them off the branch.
        new_node_id = (data.get("node_id") or "").strip()
        if new_node_id:
            self._cursor = new_node_id

        output = (data.get("output") or "").strip()
        if output:
            # markup=False: command output is arbitrary text and may contain
            # square brackets (dict reprs, log lines, [tags]), which Rich would
            # otherwise try to parse as style markup and either swallow or error
            # on. Colour comes from style= instead.
            for line in output.splitlines():
                self._console.print(
                    f"  {line}", markup=False, style=c('tool_ok'))
        return True

    # --- Clipboard helpers ---

    def _read_clipboard_text(self) -> str:
        try:
            import subprocess
            result = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "Get-Clipboard -Raw"],
                capture_output=True, text=True, timeout=2,
                encoding="utf-8", errors="replace",
            )
            if result.returncode == 0:
                return result.stdout
        except Exception:
            pass
        return ""

    def _write_clipboard_text(self, text: str) -> bool:
        if not text:
            return False
        try:
            import subprocess
            result = subprocess.run(
                ["powershell", "-NoProfile", "-NonInteractive", "-Command",
                 "Set-Clipboard -Value ([Console]::In.ReadToEnd())"],
                input=text, capture_output=True, text=True, timeout=2,
                encoding="utf-8", errors="replace",
            )
            return result.returncode == 0
        except Exception:
            return False

    # --- Reply display helpers ---

    def _start_reply(self):
        if not self._label_printed:
            t = self._theme.t
            c = self._theme.c
            self._console.print(f"{t('agent_label')}:", style=c('agent_label'))
            self._label_printed = True
            self._printed_block = False

    # --- Append-only streaming renderer ---
    #
    # Nothing on screen is ever repainted. Each completed markdown block is
    # printed exactly once and never touched again.
    #
    # This replaced a rich.live.Live region, which repainted by moving the
    # cursor up over its previous output. That had two failure modes:
    #   * a render taller than the terminal could not be scrolled back over,
    #     so every refresh re-printed the whole reply — the duplicated-message
    #     bug;
    #   * scrolling mid-reply desynced Rich's idea of the cursor position from
    #     the real one, smearing output across the screen.
    # Both are structurally impossible when output is append-only.
    #
    # Markdown still renders properly because blocks are only flushed at true
    # block boundaries — a blank line outside a fence, or a closing fence.
    # Those are exactly markdown's own block separators, so headings, lists,
    # tables and code fences are always handed to Markdown() as whole units.

    @staticmethod
    def _split_blocks(buf: str) -> tuple[list[str], str]:
        """
        Split `buf` into (complete markdown blocks, unfinished remainder).

        Only fully-received lines are considered — the text after the last
        newline is still being streamed and always stays in the remainder.
        """
        lines = buf.split("\n")
        blocks: list[str] = []
        cur: list[str] = []
        in_fence = False
        cut = 0  # index of the first line not yet flushed

        for i, line in enumerate(lines[:-1]):
            if line.lstrip().startswith("```"):
                cur.append(line)
                in_fence = not in_fence
                if not in_fence:          # fence just closed → block complete
                    blocks.append("\n".join(cur))
                    cur = []
                    cut = i + 1
                continue
            if not in_fence and not line.strip():
                if cur:
                    blocks.append("\n".join(cur))
                    cur = []
                cut = i + 1
                continue
            cur.append(line)

        return blocks, "\n".join(lines[cut:])

    def _print_block(self, block: str) -> None:
        """
        Render one markdown block and append it to the screen.

        Blocks are rendered independently, so Rich's own inter-block spacing
        (which it only applies *within* a single Markdown render) is gone. We
        capture each block, trim the blank lines Rich puts around things like
        code fences and tables, and re-insert exactly one blank line between
        blocks — so spacing is uniform no matter how the stream was chunked.
        """
        with self._console.capture() as cap:
            self._console.print(Markdown(_preprocess(block)))
        body = cap.get().strip("\n")
        if not body:
            return
        if self._printed_block:
            self._console.file.write("\n")
        self._console.file.write(body + "\n")
        self._console.file.flush()
        self._printed_block = True

    def _emit_text(self, text: str) -> None:
        """Buffer streamed text and print whole markdown blocks as they close."""
        self._stream_buf += text
        blocks, self._stream_buf = self._split_blocks(self._stream_buf)
        for block in blocks:
            self._print_block(block)

    def _flush_stream(self) -> None:
        """Print whatever is left in the buffer (end of message / before a tool)."""
        rest = self._stream_buf.strip()
        self._stream_buf = ""
        if rest:
            self._print_block(rest)

    def _emit_thinking(self, text: str) -> None:
        """Print completed thinking lines as dim plain text (never markdown)."""
        c = self._theme.c
        if not self._thinking_shown:
            self._console.print(f" [{c('thinking')}]⠋ thinking...[/{c('thinking')}]")
            self._thinking_shown = True
        if not self._show_thinking:
            return
        self._think_buf += text
        *done, self._think_buf = self._think_buf.split("\n")
        for line in done:
            self._console.print(f"   {line}", markup=False, style=c('thinking'))

    async def handle_event(self, event) -> None:
        c = self._theme.c

        if isinstance(event, (AgentThinkingChunk, _FakeThinkingChunk)):
            self._start_reply()
            self._emit_thinking(event.text or "")

        elif isinstance(event, (AgentTextChunk, _FakeTextChunk)):
            self._start_reply()
            self._current_content += event.text
            self._emit_text(event.text)

        elif isinstance(event, (AgentToolCall, _FakeToolCall)):
            self._flush_stream()
            self._current_content = ""
            def _truncate(v, max_chars=80) -> str:
                r = repr(v)
                return r[:max_chars] + "..." if len(r) > max_chars else r
            args_str = ", ".join(
                f"{k}={_truncate(v)}" for k, v in event.args.items())
            self._console.print(
                f"  [{c('tool_call')}]⟶  {event.tool_name}({args_str})[/{c('tool_call')}]")

        elif isinstance(event, (AgentToolResult, _FakeToolResult)):
            status_color = c("tool_error") if event.is_error else c("tool_ok")
            icon = "✗" if event.is_error else "✓"
            preview = (event.output[:100].replace("\n", " ")
                       + ("..." if len(event.output) > 100 else ""))
            self._console.print(
                f"  [{status_color}]{icon}  {event.tool_name}:[/{status_color}] ",
                end="")
            self._console.print(preview, markup=False, style="bright_black")
        elif isinstance(event, (AgentTextFinal, _FakeTextFinal)):
            # NO_REPLY: drop the buffer unprinted. The sentinel is a bare token
            # with no trailing blank line, so _emit_text() will still be holding
            # it in _stream_buf and nothing has reached the screen yet.
            suppressed = getattr(event, "suppressed", False)
            if suppressed:
                self._stream_buf = ""
                self._current_content = ""
                self._console.print(f"  [{c('tool_ok')}]·  (no reply)[/{c('tool_ok')}]")
            elif self._current_content:
                # Already streamed and printed block by block — just flush the tail.
                self._flush_stream()
                self._last_reply = self._current_content.strip()
            else:
                # Non-streaming provider: the whole reply arrives here at once.
                final_text = (event.text or "").strip()
                if final_text:
                    self._console.print(Markdown(_preprocess(final_text)))
                    self._last_reply = final_text

            self._current_content = ""
            self._stream_buf = ""
            self._think_buf = ""
            self._thinking_shown = False
            self._label_printed = False
            self._printed_block = False
            self._reply_done.set()

        elif isinstance(event, (AgentError, _FakeError)):
            self._flush_stream()
            self._current_content = ""
            self._console.print(
                f"\n[{c('error')}]error: {event.message}[/{c('error')}]\n")
            self._reply_done.set()

    # --- HTTP send (replaces router.push) ---

    async def _send(self, text: str, attachments=()) -> None:
        """
        POST a message to /v1/lane/message, consume the SSE stream,
        feed each event into handle_event, and advance the local cursor
        on the done event.
        """
        import aiohttp

        payload: dict = {"node_id": self._cursor, "text": text, "permission_level": 100}
        if self._cli_username:
            payload["cli_username"] = self._cli_username
        if self._cli_agent_name:
            payload["agent_name"] = self._cli_agent_name
        if attachments:
            payload["attachments"] = attachments

        url = f"{self._gateway_url}/v1/lane/message"

        # Use a large max_line_size so big tool_result SSE lines don't hit
        # aiohttp's default 131072-byte readline cap.
        _MAX_LINE = 8 * 1024 * 1024  # 8 MB

        connector = aiohttp.TCPConnector()
        async with aiohttp.ClientSession(
            connector=connector,
            read_bufsize=_MAX_LINE,
        ) as session:
            async with session.post(
                url, json=payload, headers=self._http_headers()
            ) as resp:
                resp.raise_for_status()
                while True:
                    try:
                        raw_line = await resp.content.readuntil(
                            b"\n", max_size=_MAX_LINE
                        )
                    except Exception:
                        raw_line = b""
                    if not raw_line:
                        break
                    line = raw_line.decode("utf-8", errors="replace").strip()
                    if not line.startswith("data:"):
                        continue
                    data_str = line[len("data:"):].strip()
                    try:
                        data = json.loads(data_str)
                    except json.JSONDecodeError:
                        continue

                    event_type = data.get("type")

                    if event_type == "thinking_chunk":
                        await self.handle_event(_FakeThinkingChunk(data.get("text", "")))
                    elif event_type == "text_chunk":
                        await self.handle_event(_FakeTextChunk(data.get("text", "")))
                    elif event_type == "text_final":
                        await self.handle_event(_FakeTextFinal(
                            data.get("text", ""),
                            bool(data.get("suppressed", False)),
                        ))
                    elif event_type == "tool_call":
                        await self.handle_event(_FakeToolCall(
                            data.get("tool_name", ""),
                            data.get("call_id", ""),
                            data.get("args", {}),
                        ))
                    elif event_type == "tool_result":
                        await self.handle_event(_FakeToolResult(
                            data.get("tool_name", ""),
                            data.get("call_id", ""),
                            data.get("output", ""),
                            bool(data.get("is_error", False)),
                        ))
                    elif event_type == "outbound_files":
                        paths = data.get("paths", [])
                        if paths:
                            self._flush_stream()
                            c = self._theme.c
                            self._console.print(
                                f"  [{c('tool_ok')}]↓  files delivered:[/{c('tool_ok')}]")
                            for p in paths:
                                self._console.print(
                                    f"     {p}", markup=False, style="bright_black")
                    elif event_type == "error":
                        await self.handle_event(_FakeError(data.get("message", "")))
                    elif event_type == "done":
                        new_tail = data.get("node_id")
                        if new_tail:
                            self._cursor = new_tail
                            if self._instance_dir:
                                _save_cli_cursor_path(self._instance_dir, new_tail)
                        break

    async def _prompt(self, prompt_str: str) -> str:
        loop = asyncio.get_event_loop()
        try:
            return await loop.run_in_executor(None, lambda: input(prompt_str))
        except (asyncio.CancelledError, EOFError):
            raise EOFError

    async def _handle_help(self) -> None:
        """
        Print built-in commands, then fetch module-registered commands from
        GET /v1/commands and append them to the listing.
        """
        c = self._theme.c

        # Built-in commands always available locally.
        builtin_rows = [
            ("/reset",  "Start a new session branch"),
            ("/resume [node_id]", "Reattach to the session from before this launch, or to node_id"),
            ("/copy",   "Copy last agent reply to clipboard"),
            ("/paste",  "Submit clipboard contents as next message"),
            ("/think",  "Toggle display of thinking content (currently " +
                        ("on" if self._show_thinking else "off") + ")"),
            ("/help",   "Show this help"),
        ]

        # Module-registered commands from the gateway.
        module_rows: list[tuple[str, str]] = []
        try:
            data = await self._api_get("/v1/commands")
            for entry in data.get("commands", []):
                cmd  = entry.get("command", "")
                hlp  = entry.get("help", "")
                if cmd:
                    module_rows.append((cmd, hlp))
        except Exception as exc:
            logger.debug("[cli] could not fetch /v1/commands: %s", exc)

        all_rows = sorted(builtin_rows + module_rows, key=lambda r: r[0])

        self._console.print(
            f"[{c('border')}]available commands:[/{c('border')}]")
        for cmd, help_text in all_rows:
            self._console.print(
                f"  [{c('tool_call')}]{cmd}[/{c('tool_call')}]  {help_text}")

    async def run(self) -> None:
        logging.basicConfig(
            level=logging.WARNING,
            format="%(message)s",
            datefmt="[%X]",
            handlers=[RichHandler(console=self._console,
                                  rich_tracebacks=True, markup=False)],
            force=True,
        )
        logging.getLogger("markdown_it").setLevel(logging.WARNING)

        banner_text = Text()
        banner_text.append(
            pyfiglet.figlet_format(self._theme.t("name"), font="slant"),
            style=self._theme.c("banner"),
        )
        banner_text.append(
            f"  {self._theme.t('tagline')}", style=self._theme.c("tagline"))
        self._console.print(Panel(
            banner_text,
            border_style=self._theme.c("border"),
            padding=(0, 2),
        ))
        self._console.print(
            f"[{self._theme.c('border')}]"
            "  type a message · /resume · /reset · /help · exit"
            f"[/{self._theme.c('border')}]\n"
        )

        c = self._theme.c
        t = self._theme.t

        ANSI_RESET = "\033[0m"
        ANSI_GREEN = "\033[32m"
        prompt_str = f"{ANSI_GREEN}{t('user_label')}{ANSI_RESET}: "

        while True:
            try:
                text = await self._prompt(prompt_str)
                text = text.strip()
                if not text:
                    continue
                if text.lower() in {"exit", "quit"}:
                    break

                if text.startswith("/"):
                    lower = text.lower()

                    # --------------------------------------------------------
                    # Built-in: /reset
                    # --------------------------------------------------------
                    if lower == "/reset":
                        branch_data = await self._api_post(
                            "/v1/lane/branch", {"parent_node_id": None})
                        new_node_id = branch_data["node_id"]
                        await self._api_post(
                            "/v1/lane/open", {"node_id": new_node_id})
                        self._cursor = new_node_id
                        if self._instance_dir:
                            _save_cli_cursor_path(self._instance_dir, new_node_id)
                        self._console.print(
                            f"[{c('reset')}]  ↺  new session started"
                            f"[/{c('reset')}]")
                        continue

                    # --------------------------------------------------------
                    # Built-in: /resume [node_id] — reattach to the session
                    # that was active before this launch started a fresh
                    # branch, or to an explicit node_id if one is given.
                    # --------------------------------------------------------
                    if lower == "/resume" or lower.startswith("/resume "):
                        arg = text[len("/resume"):].strip()  # preserve case
                        target_node = arg or self._resume_cursor
                        if not target_node:
                            self._console.print(
                                f"[{c('reset')}]  ·  no previous session to resume"
                                f"[/{c('reset')}]")
                            continue
                        data = await self._api_post(
                            "/v1/lane/open", {"node_id": target_node})
                        opened_node = data.get("node_id")
                        # /v1/lane/open silently starts a fresh branch when
                        # node_id is unknown instead of erroring — a mismatch
                        # between what we asked for and what came back is how
                        # we detect that and report it instead of quietly
                        # resuming the wrong (new) session.
                        if arg and opened_node != target_node:
                            self._console.print(
                                f"[{c('error')}]  ✗  session '{target_node}' not found"
                                f"[/{c('error')}]")
                            continue
                        self._cursor = opened_node
                        if self._instance_dir:
                            _save_cli_cursor_path(self._instance_dir, self._cursor)
                        label = f"resumed session {opened_node}" if arg else "resumed previous session"
                        self._console.print(
                            f"[{c('reset')}]  ⟲  {label}"
                            f"[/{c('reset')}]")
                        continue

                    # --------------------------------------------------------
                    # Built-in: /copy
                    # --------------------------------------------------------
                    if lower.startswith("/copy"):
                        copied = self._write_clipboard_text(self._last_reply)
                        if copied:
                            self._console.print(
                                f"[{c('tool_ok')}]  ✓  copied last reply to clipboard"
                                f"[/{c('tool_ok')}]")
                        else:
                            self._console.print(
                                f"[{c('tool_error')}]  ✗  nothing to copy"
                                f"[/{c('tool_error')}]")
                        continue

                    # --------------------------------------------------------
                    # Built-in: /paste  (falls through to _send below)
                    # --------------------------------------------------------
                    if lower.startswith("/paste"):
                        pasted = self._read_clipboard_text().strip()
                        if not pasted:
                            self._console.print(
                                f"[{c('tool_error')}]  ✗  clipboard is empty"
                                f"[/{c('tool_error')}]")
                            continue
                        self._console.print(
                            f"[{c('tool_call')}]  (pasting {len(pasted)} chars "
                            f"from clipboard)[/{c('tool_call')}]")
                        text = pasted
                        # Falls through to _send below.

                    # --------------------------------------------------------
                    # Built-in: /think
                    # --------------------------------------------------------
                    elif lower == "/think":
                        self._show_thinking = not self._show_thinking
                        state = "on" if self._show_thinking else "off"
                        self._console.print(
                            f"[{c('reset')}]  💭  thinking display {state}"
                            f"[/{c('reset')}]")
                        continue

                    # --------------------------------------------------------
                    # Built-in: /help
                    # --------------------------------------------------------
                    elif lower in {"/help", "/?"}:
                        await self._handle_help()
                        continue

                    # --------------------------------------------------------
                    # Module slash commands — dispatch to gateway first.
                    # If the gateway handles it, we're done.
                    # If not, surface an "unknown command" error.
                    # --------------------------------------------------------
                    else:
                        handled = await self._dispatch_gateway_command(text)
                        if not handled:
                            self._console.print(
                                f"[{c('error')}]  unknown command: {text}"
                                f"  (try /help)[/{c('error')}]")
                        continue

                self._reply_done.clear()
                await self._send(text)
                # _send() drives the full SSE loop and sets _reply_done
                # indirectly via handle_event on AgentTextFinal/AgentError.

            except (KeyboardInterrupt, EOFError):
                break

        self._console.print(f"[{c('reset')}]{t('bye_message')}[/{c('reset')}]")


# ---------------------------------------------------------------------------
# Cursor file helpers (client-side) — <instance>/data/cursors/cli
#
# Lives in data/, not workspace/, for the same reason as the Discord
# bridge's CursorStore: this is bridge bookkeeping (which conversation node
# the CLI resumes from), not agent-authored content.
# ---------------------------------------------------------------------------

def _cursor_file_path(instance_dir: Path) -> Path:
    return instance_dir / "data" / "cursors" / "cli"


def _load_cli_cursor_path(instance_dir: Path) -> str | None:
    try:
        cursor_file = _cursor_file_path(instance_dir)
        if cursor_file.exists():
            return cursor_file.read_text(encoding="utf-8").strip() or None
    except Exception:
        pass
    return None


def _save_cli_cursor_path(instance_dir: Path, node_id: str) -> None:
    try:
        cursor_file = _cursor_file_path(instance_dir)
        cursor_file.parent.mkdir(parents=True, exist_ok=True)
        cursor_file.write_text(node_id, encoding="utf-8")
    except Exception:
        pass


# ---------------------------------------------------------------------------
# Entry points
# ---------------------------------------------------------------------------

async def run(gateway) -> None:
    """
    Called by main.py bridge loader. Skipped before reaching here because
    MANUAL_LAUNCH = True, but kept as a no-op for safety.
    """
    pass


async def run_detached(
    gateway_url: str,
    api_key: str,
    options: dict | None = None,
    username: str | None = None,
    instance_dir: Path | None = None,
) -> None:
    """
    Real entry point — called by commands/launch.py.
    Connects to the running daemon over HTTP and runs the interactive TUI.

    username: TinyCTX username resolved and (optionally) elevated by launch.py.
              Forwarded in every message body so the gateway can author messages
              as that user rather than the generic api-client.
    instance_dir: resolved .tinyctx instance directory (see utils/instance.py),
                  used only to locate this instance's cursor file under data/cursors/.
                  Falls back to ~/.tinyctx if not supplied (back-compat).
    """
    import aiohttp

    if instance_dir is None:
        instance_dir = Path.home() / ".tinyctx"

    bridge = CLIBridge(None, options=options or {})
    bridge._gateway_url = gateway_url
    bridge._api_key     = api_key
    bridge._cli_username = username  # forwarded in _send()
    bridge._cli_agent_name = (options or {}).get("agent_name") or None  # forwarded in _send()
    bridge._instance_dir = instance_dir

    # Each launch starts a fresh branch by default, so a new session doesn't
    # silently inherit the previous one's context. The old cursor is kept in
    # _resume_cursor so /resume can reattach to it. Set default_to_resume: true
    # under bridges.cli.options to reattach automatically instead.
    saved_cursor = _load_cli_cursor_path(instance_dir)
    bridge._resume_cursor = saved_cursor

    async with aiohttp.ClientSession() as session:
        open_node = saved_cursor
        if not (bridge._default_to_resume and saved_cursor):
            resp = await session.post(
                f"{gateway_url}/v1/lane/branch",
                json={"parent_node_id": None},
                headers=bridge._http_headers(),
            )
            resp.raise_for_status()
            open_node = (await resp.json())["node_id"]

        resp = await session.post(
            f"{gateway_url}/v1/lane/open",
            json={"node_id": open_node},
            headers=bridge._http_headers(),
        )
        resp.raise_for_status()
        data = await resp.json()

    bridge._cursor = data["node_id"]
    _save_cli_cursor_path(instance_dir, bridge._cursor)

    await bridge.run()
